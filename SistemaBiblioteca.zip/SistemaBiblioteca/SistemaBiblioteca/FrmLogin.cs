using SistemaBiblioteca.Model;
using System.Linq;
using System.Windows.Forms;

namespace SistemaBiblioteca
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            DefinirLogin();
        }

        private bool ValidaUsuario()
        {
            Model.Usuario Usuario = new Model.Usuario
            {
                Email = txtEmail.Text,
                Senha = txtSenha.Text,
            };
            List<Model.Usuario> Lista = Model.Usuario.Login(Usuario);
            if (Lista.Count >= 1)
            {
                if (Lista[0].Email != Usuario.Email || Lista[0].Email == null)
                {
                    MessageBox.Show("O Email � inv�lido", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.Focus();
                    return false;

                }
                else if (Lista[0].Senha != Usuario.Senha || Lista[0].Senha == null)
                {
                    MessageBox.Show("A senha � inv�lida", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtSenha.Focus();
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                MessageBox.Show("O login � inv�lido", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSenha.Focus();
                return false;
            }
            


        }
        private void DefinirLogin()
        {
            Model.Usuario Usuario = new Model.Usuario
            {
                Email = txtEmail.Text,
                Senha = txtSenha.Text,
            };
            List<Model.Usuario> Lista = Model.Usuario.Login(Usuario);

            if (ValidaUsuario())
            {
                if (Lista[0].Tipo == "Administrador")
                {
                    FrmMenu oFrmMenu = new FrmMenu("ADM");

                    oFrmMenu.Show();
                    this.Hide();
                }
                else
                {
                    FrmMenu oFrmMenu = new FrmMenu("Outro");

                    oFrmMenu.Show();
                    this.Hide();
                }
            }
            

         
        }
    }
}



