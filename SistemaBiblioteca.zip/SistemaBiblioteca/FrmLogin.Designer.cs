﻿namespace SistemaBiblioteca
{
    partial class FrmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLogin = new Button();
            lblEmail = new Label();
            lblSenha = new Label();
            lblTextin = new Label();
            txtEmail = new TextBox();
            txtSenha = new TextBox();
            groupBox1 = new GroupBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(78, 283);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(94, 29);
            btnLogin.TabIndex = 0;
            btnLogin.Text = "Entrar";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(29, 111);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(46, 20);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Email";
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(29, 195);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(49, 20);
            lblSenha.TabIndex = 2;
            lblSenha.Text = "Senha";
            // 
            // lblTextin
            // 
            lblTextin.AutoSize = true;
            lblTextin.Font = new Font("Segoe UI", 18F);
            lblTextin.Location = new Point(14, 36);
            lblTextin.Name = "lblTextin";
            lblTextin.Size = new Size(230, 41);
            lblTextin.TabIndex = 3;
            lblTextin.Text = "Seja Bem-Vindo";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(29, 145);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(186, 27);
            txtEmail.TabIndex = 4;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(29, 231);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(186, 27);
            txtSenha.TabIndex = 5;
            txtSenha.UseSystemPasswordChar = true;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.None;
            groupBox1.Controls.Add(lblTextin);
            groupBox1.Controls.Add(txtSenha);
            groupBox1.Controls.Add(btnLogin);
            groupBox1.Controls.Add(txtEmail);
            groupBox1.Controls.Add(lblEmail);
            groupBox1.Controls.Add(lblSenha);
            groupBox1.Location = new Point(271, 53);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 337);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            Name = "FrmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnLogin;
        private Label lblEmail;
        private Label lblSenha;
        private Label lblTextin;
        private TextBox txtEmail;
        private TextBox txtSenha;
        private GroupBox groupBox1;
    }
}
