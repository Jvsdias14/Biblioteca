﻿using Microsoft.Data.SqlClient;
using SistemaBiblioteca.Helper;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace SistemaBiblioteca.Model
{
    public class Livro
    {
        //public int Id { get; set; }
        private int _Codigo;
        private string _Idioma;
        private string _Genero;
        private string _Editora;
        private string _ISBN;
        private string _Nome;
        private string _Descricao;
        private int _Edicao;
        private int _QtdPaginas;
        private int _IdIdioma;
        private int _IdGenero;
        private int _IdEditora;
        private string _Autor;
        private List<int> _idAutores;
        private List<string> _NomeAutores;

        public int Id
        {
            get { return _Codigo; }
            set { _Codigo = value; }

        }
        public string Nome { get => _Nome; set => _Nome = value.Replace("'", ""); }
        public string Idioma { get => _Idioma; set => _Idioma = value.Replace("'", ""); }
        public string Genero { get => _Genero; set => _Genero = value.Replace("'", ""); }
        public string Editora { get => _Editora; set => _Editora = value.Replace("'", ""); }
        public string ISBN { get => _ISBN; set => _ISBN = value.Replace("'", ""); }
        public string Descricao { get => _Descricao; set => _Descricao = value.Replace("'", ""); }
        public int Edicao { get => _Edicao; set => _Edicao = value; }
        public int Paginas { get => _QtdPaginas; set => _QtdPaginas = value; }
        public string Autor { get => _Autor; set => _Autor = value.Replace("'", ""); }
        public int IdIdioma { get => _IdIdioma; set => _IdIdioma = value; }
        public int IdGenero { get => _IdGenero; set => _IdGenero = value; }
        public int IdEditora { get => _IdEditora; set => _IdEditora = value; }


        public List<int> IdAutores
        {
            get => _idAutores;
            set => _idAutores = value;
        }
        public List<string> NomeAutores
        {
            get => _NomeAutores;
            set => _NomeAutores = value;
        }

        public static List<Livro> ListarTodos()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();

                string SQL = "SELECT LV.ID, LV.ISBN, LV.Nome as 'Livro', LV.Descricao, ED.Nome as 'Editora', LV.Edicao, LV.Paginas, IM.Nome as 'Idioma', GE.Nome as 'Genero' FROM Livro LV\r\nLEFT JOIN Idioma IM ON IM.Id = LV.IdIdioma\r\nLEFT JOIN Editora ED ON ED.Id = LV.IdEditora\r\nLEFT JOIN Genero GE ON GE.Id = LV.IdGenero";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro.Nome = oDr.GetString(oDr.GetOrdinal("Livro"));
                    oLivro.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro.Editora = oDr.GetString(oDr.GetOrdinal("Editora"));
                    oLivro.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro.Paginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro.Idioma = oDr.GetString(oDr.GetOrdinal("Idioma"));
                    oLivro.Genero = oDr.GetString(oDr.GetOrdinal("Genero"));

                    Retorno.Add(oLivro);
                }
                oDr.Close();
                return Retorno;
            }

            //return (from p in DataHelper.ListaLivro select p).ToList();
        }

        public void Incluir()
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = "Insert into Livro Values(@Idioma,@Editora,@Genero,@ISBN,@Nome,@Descricao,@Paginas,@Edicao)";
                using (SqlCommand comando = new SqlCommand(SQL, conexao))
                {
                    // Adiciona os parâmetros com os valores respectivos

                    comando.Parameters.AddWithValue("@Idioma", this.IdIdioma);
                    comando.Parameters.AddWithValue("@Editora", this.IdEditora);
                    comando.Parameters.AddWithValue("@Genero", this.IdGenero);
                    comando.Parameters.AddWithValue("@ISBN", this.ISBN.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Nome", this.Nome.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Descricao", this.Descricao.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Paginas", this.Paginas);
                    comando.Parameters.AddWithValue("@Edicao", this.Edicao);
                    //comando.Parameters.AddWithValue("@Autor", this.Autor);
                    comando.ExecuteNonQuery();
                }
                Livro oLivro = new Livro();
                string SQL2 = "Select MAX(id) as id from Livro";
                SqlCommand comando2 = new SqlCommand(SQL2, conexao);
                SqlDataReader oDr2 = comando2.ExecuteReader();
                oDr2.Read();
                oLivro.Id = oDr2.GetInt32(oDr2.GetOrdinal("id"));
                oDr2.Close();

                for (int i = 0; i < this.IdAutores.LongCount(); i++)
                {
                    string SQL3 = $"Insert into LivroAutor values ({this.IdAutores[i]},{oLivro.Id})";
                    using (SqlCommand comando3 = new SqlCommand(SQL3, conexao))
                    {
                        comando3.ExecuteNonQuery();
                    }
                }

            }
        }

        public static void Alterar(Livro oLivro)
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = "UPDATE Livro SET Nome = @Nome, IdIdioma = @Idioma, IdGenero = @Genero, IdEditora = @Editora, ISBN = @ISBN, Descricao = @Descricao, Edicao = @Edicao, Paginas = @Paginas WHERE id = @Id";
                using (SqlCommand comando = new SqlCommand(SQL, conexao))
                {
                    // Adiciona os parâmetros com os valores respectivos
                    comando.Parameters.AddWithValue("@Idioma", oLivro.IdIdioma);
                    comando.Parameters.AddWithValue("@Editora", oLivro.IdEditora);
                    comando.Parameters.AddWithValue("@Genero", oLivro.IdGenero);
                    comando.Parameters.AddWithValue("@ISBN", oLivro.ISBN.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Nome", oLivro.Nome.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Descricao", oLivro.Descricao.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Paginas", oLivro.Paginas);
                    comando.Parameters.AddWithValue("@Edicao", oLivro.Edicao);
                    comando.Parameters.AddWithValue("@Id", oLivro.Id);
                    comando.ExecuteNonQuery();

                }
                List<Autor> Retorno = new List<Autor>();
                string SQL2 = $"select * from LivroAutor where IdLivro = {oLivro.Id}";
                SqlCommand comando2 = new SqlCommand(SQL2, conexao);
                SqlDataReader oDr = comando2.ExecuteReader();
                while (oDr.Read())
                {
                    Autor oAutor = new Autor();
                    oAutor.Id = oDr.GetInt32(oDr.GetOrdinal("idAutor"));
                    Retorno.Add(oAutor);
                }
                oDr.Close();

                {
                    List<int> listaCadastrar = new List<int>();
                    List<int> listaDeletar = new List<int>();

                    foreach (var autorAntigo in Retorno)
                    {
                        if (oLivro.IdAutores.Contains(autorAntigo.Id))
                        {
                            oLivro.IdAutores.Remove(autorAntigo.Id);
                        }
                        else
                        {
                            listaDeletar.Add(autorAntigo.Id);
                        }
                    }
                    listaCadastrar.AddRange(oLivro.IdAutores);
                    foreach (var autor in listaDeletar)
                    {
                        string SQL3 = $"delete from LivroAutor where IdAutor = {autor} and IdLivro = {oLivro.Id}";
                        SqlCommand comando = new SqlCommand(SQL3, conexao);
                        comando.ExecuteNonQuery();
                    }
                    foreach (var autor in listaCadastrar)
                    {
                        string SQL4 = $"insert into LivroAutor values ({autor},{oLivro.Id})";
                        SqlCommand comando = new SqlCommand(SQL4, conexao);
                        comando.ExecuteNonQuery();
                    }

                }

            }
        }

        public void Excluir()
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = $"delete from LivroAutor where idLivro={this.Id}\ndelete from Livro where id={this.Id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                comando.ExecuteNonQuery();
            }
        }

        public static List<Livro> SelecionarPorChave(Livro oLivro)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();
                List<string> lista = VerificarCamposNaoPreenchidos(oLivro);
                List<PropertyInfo> atributos = VerificarPreenchidos(oLivro);
                List<string> lista2 = new List<string>();

                if (atributos.LongCount() != 0)
                {
                    for (int i = 0; i < atributos.LongCount(); i++)
                    {
                        var valor = atributos[i].GetValue(oLivro);
                        if (valor is string)
                        {
                            string condicao = $"{lista[i]} = '{atributos[i].GetValue(oLivro)}'";
                            lista2.Add(condicao);
                        }
                        else
                        {
                            string condicao = $"{lista[i]} = {atributos[i].GetValue(oLivro)}";
                            lista2.Add(condicao);
                        }
                    }
                }
                else
                {
                    string condicao = $"Nome = '' ";
                    lista2.Add(condicao);
                }
            

                string where = string.Join(" AND ", lista2 );
                Dictionary<string, string> substitutions = new Dictionary<string, string>
        {
                { @"\bid\b", "LV.id" },
                { @"\bNome\b", "LV.Nome" }
        };

                string whereAtualizada = MultipleRegexReplace(where, substitutions, RegexOptions.IgnoreCase);
                
                string SQL = $"SELECT LV.ID, LV.ISBN, LV.Nome as 'Livro', LV.Descricao, ED.Nome as 'Editora', LV.Edicao, LV.Paginas, IM.Nome as 'Idioma', GE.Nome as 'Genero' FROM Livro LV\r\nLEFT JOIN Idioma IM ON IM.Id = LV.IdIdioma\r\nLEFT JOIN Editora ED ON ED.Id = LV.IdEditora\r\nLEFT JOIN Genero GE ON GE.Id = LV.IdGenero where {whereAtualizada}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro2 = new Livro();
                    oLivro2.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro2.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro2.Nome = oDr.GetString(oDr.GetOrdinal("Livro"));
                    oLivro2.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro2.Editora = oDr.GetString(oDr.GetOrdinal("Editora"));
                    oLivro2.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro2.Paginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro2.Idioma = oDr.GetString(oDr.GetOrdinal("Idioma"));
                    oLivro2.Genero = oDr.GetString(oDr.GetOrdinal("Genero"));
                    Retorno.Add(oLivro2);
                }
                oDr.Close();
                return Retorno;
            }

            //return (from p in DataHelper.ListaLivro select p).ToList();
        }

        public static List<Autor> CarregaAutores(Livro oLivro)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Autor> Retornoteste = new List<Autor>();

                string SQL = $"Select  AU.ID as 'id',AU.Nome as 'Nome' from LivroAutor LA\r\nLeft Join Livro LV on LV.id = LA.IdLivro\r\nLEFT JOIN Autor AU on AU.id = LA.IdAutor\r\nwhere LA.IdLivro = {oLivro.Id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Autor oAutor = new Autor();
                    oAutor.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oAutor.Nome = oDr.GetString(oDr.GetOrdinal("Nome"));

                    Retornoteste.Add(oAutor);
                }
                oDr.Close();
                return Retornoteste;
            }
        }
        public static List<Autor> ListarTodosAutores()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Autor> Retorno = new List<Autor>();
                string SQL = "select * from autor";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Autor oAutor = new Autor();
                    oAutor.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oAutor.Nome = oDr.GetString(oDr.GetOrdinal("Nome"));
                    Retorno.Add(oAutor);
                }
                oDr.Close();
                return Retorno;
            }

            //return (from p in DataHelper.ListaAutor select p).ToList();
        }
        public static void ExcluirAutor(Autor oAutor, Livro oLivro)
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = $"delete from LivroAutor where idAutor={oAutor.Id} and idLivro = {oLivro.Id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                comando.ExecuteNonQuery();
            }
        }

        public static List<string> VerificarCamposNaoPreenchidos(Livro livro)
        {
            List<string> camposNaoPreenchidos = new List<string>();

            PropertyInfo[] propriedades = typeof(Livro).GetProperties();

            foreach (var propriedade in propriedades)
            {
                var valor = propriedade.GetValue(livro);

                if (valor == null ||
                (propriedade.PropertyType == typeof(string) && string.IsNullOrWhiteSpace((string)valor)) ||
                (propriedade.PropertyType.IsValueType && Activator.CreateInstance(propriedade.PropertyType).Equals(valor)))
                {
                    
                }
                else
                {
                    camposNaoPreenchidos.Add(propriedade.Name);
                }
            }
            return camposNaoPreenchidos;
        }
        public static List<PropertyInfo> VerificarPreenchidos(Livro livro)
        {
            List<PropertyInfo> camposNaoPreenchidos = new List<PropertyInfo>();

            PropertyInfo[] propriedades = typeof(Livro).GetProperties();

            foreach (var propriedade in propriedades)
            {
                var valor = propriedade.GetValue(livro);

                if (valor == null ||
                (propriedade.PropertyType == typeof(string) && string.IsNullOrWhiteSpace((string)valor)) ||
                (propriedade.PropertyType.IsValueType && Activator.CreateInstance(propriedade.PropertyType).Equals(valor)))
                {
                    
                }
                else
                {
                    camposNaoPreenchidos.Add(propriedade);
                }
            }

            return camposNaoPreenchidos;
        }
        public static string MultipleRegexReplace(string input, Dictionary<string, string> replacements, RegexOptions options)
        {
            foreach (var item in replacements)
            {
                input = Regex.Replace(input, item.Key, item.Value, options);
            }
            return input;
        }
        public static List<Livro> PesquisarPorGenero(int id)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();
                string SQL = $"select * from Livro where IdGenero = {id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro.Nome = oDr.GetString(oDr.GetOrdinal("Nome"));
                    oLivro.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro.IdEditora = oDr.GetInt32(oDr.GetOrdinal("IdEditora"));
                    oLivro.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro.Paginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro.IdIdioma = oDr.GetInt32(oDr.GetOrdinal("IdIdioma"));
                    oLivro.IdGenero = oDr.GetInt32(oDr.GetOrdinal("IdGenero"));

                    Retorno.Add(oLivro);
                }
                oDr.Close();
                return Retorno;
            }
        }
        public static List<Livro> PesquisarPorIdioma(int id)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();
                string SQL = $"select * from Livro where IdIdioma = {id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro.Nome = oDr.GetString(oDr.GetOrdinal("Nome"));
                    oLivro.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro.IdEditora = oDr.GetInt32(oDr.GetOrdinal("IdEditora"));
                    oLivro.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro.Paginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro.IdIdioma = oDr.GetInt32(oDr.GetOrdinal("IdIdioma"));
                    oLivro.IdGenero = oDr.GetInt32(oDr.GetOrdinal("IdGenero"));

                    Retorno.Add(oLivro);
                }
                oDr.Close();
                return Retorno;
            }
        }
        public static List<Livro> PesquisarPorEditora(int id)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();
                string SQL = $"select * from Livro where IdEditora = {id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro.Nome = oDr.GetString(oDr.GetOrdinal("Nome"));
                    oLivro.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro.IdEditora = oDr.GetInt32(oDr.GetOrdinal("IdEditora"));
                    oLivro.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro.Paginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro.IdIdioma = oDr.GetInt32(oDr.GetOrdinal("IdIdioma"));
                    oLivro.IdGenero = oDr.GetInt32(oDr.GetOrdinal("IdGenero"));

                    Retorno.Add(oLivro);
                }
                oDr.Close();
                return Retorno;
            }
        }
        public static List<livroAutor> PesquisarPorAutor(int id)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<livroAutor> Retorno = new List<livroAutor>();
                string SQL = $"select * from LivroAutor where IdAutor = {id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    livroAutor oLivroAutor = new livroAutor();
                    oLivroAutor.IdAutor = oDr.GetInt32(oDr.GetOrdinal("IdAutor"));
                    oLivroAutor.IdAutor = oDr.GetInt32(oDr.GetOrdinal("IdLivro"));


                    Retorno.Add(oLivroAutor);
                }
                oDr.Close();
                return Retorno;
            }
        }
    }
}
