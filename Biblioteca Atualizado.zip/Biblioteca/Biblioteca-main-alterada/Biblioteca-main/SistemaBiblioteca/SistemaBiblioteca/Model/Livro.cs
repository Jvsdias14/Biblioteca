﻿using Microsoft.Data.SqlClient;
using SistemaBiblioteca.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace SistemaBiblioteca.Model
{
    public class Livro
    {
        //public int Id { get; set; }
        private int _Codigo;
        private string _Idioma;
        private string _Genero;
        private string _Editora;
        private string _ISBN;
        private string _Nome;
        private string _Descricao;
        private int _Edicao;
        private int _QtdPaginas;
        private string _Autor;
        public int Id
        {
            get { return _Codigo; }
            set { _Codigo = value; }

        }
        public string Nome { get => _Nome; set => _Nome = value.Replace("'", ""); }
        public string Idioma { get => _Idioma; set => _Idioma = value.Replace("'", ""); }
        public string Genero { get => _Genero; set => _Genero = value.Replace("'", ""); }
        public string Editora { get => _Editora; set => _Editora = value.Replace("'", ""); }
        public string ISBN { get => _ISBN; set => _ISBN = value.Replace("'", ""); }
        public string Descricao { get => _Descricao; set => _Descricao = value.Replace("'", ""); }
        public int Edicao { get => _Edicao; set => _Edicao = value; }
        public int QtdPaginas { get => _QtdPaginas; set => _QtdPaginas = value; }
        public string Autor { get => _Autor; set => _Autor = value.Replace("'", ""); }
        public static List<Livro> ListarTodos()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();

                string SQL = "SELECT LV.ID, LV.ISBN, LV.Nome as 'Livro', LV.Descricao, ED.Nome as 'Editora', LV.Edicao, LV.Paginas, IM.Nome as 'Idioma', GE.Nome as 'Genero', AU.Nome as 'Autor' FROM Livro LV\nLEFT JOIN LivroAutor LA ON LA.IdLivro = LV.id\nLEFT JOIN Autor AU ON AU.id = LA.IdAutor\nLEFT JOIN Idioma IM ON IM.Id = LV.IdIdioma\nLEFT JOIN Editora ED ON ED.Id = LV.IdEditora\nLEFT JOIN Genero GE ON GE.Id = LV.IdGenero";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro.Nome = oDr.GetString(oDr.GetOrdinal("Livro"));
                    oLivro.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro.Editora = oDr.GetString(oDr.GetOrdinal("Editora"));
                    oLivro.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro.QtdPaginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro.Idioma = oDr.GetString(oDr.GetOrdinal("Idioma"));
                    oLivro.Genero = oDr.GetString(oDr.GetOrdinal("Genero"));
                    oLivro.Autor = oDr.GetString(oDr.GetOrdinal("Autor"));

                    Retorno.Add(oLivro);
                }
                oDr.Close();
                return Retorno;
            }

            //return (from p in DataHelper.ListaLivro select p).ToList();
        }

        public void Incluir()
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = "Insert into Livro Values(@Idioma,@Editora,@Genero,@ISBN,@Nome,@Descricao,@QtdPaginas,@Edicao)";
                using (SqlCommand comando = new SqlCommand(SQL, conexao))
                {
                    // Adiciona os parâmetros com os valores respectivos
                    comando.Parameters.AddWithValue("@Nome", this.Nome.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Idioma", this.Idioma.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Genero", this.Genero.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Editora", this.Editora.Replace("'", ""));
                    comando.Parameters.AddWithValue("@ISBN", this.ISBN.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Descricao", this.Descricao.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Edicao", this.Edicao);
                    comando.Parameters.AddWithValue("@QtdPaginas", this.QtdPaginas);
                    //comando.Parameters.AddWithValue("@Autor", this.Autor);
                    comando.ExecuteNonQuery();
                }
                Livro oLivro = new Livro();
                string SQL2 = "Select MAX(id) as id from Livro";
                SqlCommand comando2 = new SqlCommand(SQL2, conexao);
                SqlDataReader oDr2 = comando2.ExecuteReader();
                oDr2.Read();
                oLivro.Id = oDr2.GetInt32(oDr2.GetOrdinal("id"));
                oDr2.Close();

                string SQL3 = $"Insert into LivroAutor values ({this.Autor},{oLivro.Id})";
                using (SqlCommand comando3 = new SqlCommand(SQL3, conexao))
                {
                    comando3.ExecuteNonQuery();
                }
            }
        }

        public static void Alterar(Livro oLivro)
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = "UPDATE Livro SET Nome = @Nome, Idioma = @Idioma, Genero = @Genero,Editora = @Editora, Edicao = @Edicao, ISBN = @ISBN, Descricao = @Descricao, Edicao = @Edicao, QtdPaginas = @QtdPaginas, WHERE id = @Id";
                using (SqlCommand comando = new SqlCommand(SQL, conexao))
                {
                    // Adiciona os parâmetros com os valores respectivos
                    comando.Parameters.AddWithValue("@Nome", oLivro.Nome.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Idioma", oLivro.Idioma.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Genero", oLivro.Genero.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Editora", oLivro.Editora.Replace("'", ""));
                    comando.Parameters.AddWithValue("@ISBN", oLivro.ISBN.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Descricao", oLivro.Descricao.Replace("'", ""));
                    comando.Parameters.AddWithValue("@Edicao", oLivro.Edicao);
                    comando.Parameters.AddWithValue("@QtdPaginas", oLivro.QtdPaginas);
                    comando.Parameters.AddWithValue("@Id", oLivro.Id);
                    comando.ExecuteNonQuery();
                }
            }
        }

        public void Excluir()
        {
            using (var conexao = DataHelper.Conexao())
            {
                string SQL = $"delete from LivroAutor where idLivro={this.Id}\ndelete from Livro where id={this.Id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                comando.ExecuteNonQuery();
            }
        }

        public static List<Livro> SelecionarPorChave(Livro oLivro)
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<Livro> Retorno = new List<Livro>();
                string SQL = $"select * from Livro where id = {oLivro.Id}";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro2 = new Livro();
                    oLivro2.Id = oDr.GetInt32(oDr.GetOrdinal("id"));
                    oLivro2.ISBN = oDr.GetString(oDr.GetOrdinal("ISBN"));
                    oLivro2.Nome = oDr.GetString(oDr.GetOrdinal("Livro"));
                    oLivro2.Descricao = oDr.GetString(oDr.GetOrdinal("Descricao"));
                    oLivro2.Editora = oDr.GetString(oDr.GetOrdinal("Editora"));
                    oLivro2.Edicao = oDr.GetInt32(oDr.GetOrdinal("Edicao"));
                    oLivro2.QtdPaginas = oDr.GetInt32(oDr.GetOrdinal("Paginas"));
                    oLivro2.Idioma = oDr.GetString(oDr.GetOrdinal("Idioma"));
                    oLivro2.Genero = oDr.GetString(oDr.GetOrdinal("Genero"));
                    oLivro2.Autor = oDr.GetString(oDr.GetOrdinal("Autor"));
                }
                oDr.Close();
                return Retorno;
            }

            //return (from p in DataHelper.ListaLivro select p).ToList();
        }
        public static List<string> CarregaEditoras()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<string> Retornoteste = new List<string>();

                string SQL = "SELECT nome from editora";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Editora = oDr.GetString(oDr.GetOrdinal("nome"));

                    Retornoteste.Add(oLivro.Editora);
                }
                oDr.Close();
                return Retornoteste;
            }
        }
        public static List<string> CarregaIdiomas()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<string> Retornoteste = new List<string>();

                string SQL = "SELECT nome from idioma";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Idioma = oDr.GetString(oDr.GetOrdinal("nome"));

                    Retornoteste.Add(oLivro.Idioma);
                }
                oDr.Close();
                return Retornoteste;
            }
        }
        public static List<string> CarregaGeneros()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<string> Retornoteste = new List<string>();

                string SQL = "SELECT nome from genero";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Genero = oDr.GetString(oDr.GetOrdinal("nome"));

                    Retornoteste.Add(oLivro.Genero);
                }
                oDr.Close();
                return Retornoteste;
            }
        }
        public static List<string> CarregaAutores()
        {
            using (var conexao = DataHelper.Conexao())
            {
                List<string> Retornoteste = new List<string>();

                string SQL = "SELECT nome from autor";
                SqlCommand comando = new SqlCommand(SQL, conexao);
                SqlDataReader oDr = comando.ExecuteReader();
                while (oDr.Read())
                {
                    Livro oLivro = new Livro();
                    oLivro.Autor = oDr.GetString(oDr.GetOrdinal("nome"));

                    Retornoteste.Add(oLivro.Autor);
                }
                oDr.Close();
                return Retornoteste;
            }
        }
    }
}
