﻿using SistemaBiblioteca.Helper;
using SistemaBiblioteca.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SistemaBiblioteca
{
    public partial class FrmLivro : Form
    {

        private bool Incluir = true;
        private bool Pesquisar = false;
        public FrmLivro()
        {
            InitializeComponent();
        }

        private void CarregaGrid()
        {
            if (Pesquisar)
            {
                try
                {
                    Livro oLivro = new Livro();

                    // Verificar e atribuir o valor de TxtCodigo
                    if (!string.IsNullOrWhiteSpace(TxtCodigo.Text) && int.TryParse(TxtCodigo.Text, out int id))
                    {
                        oLivro.Id = id;
                    }

                    oLivro.ISBN = txtISBN.Text;
                    oLivro.Nome = TxtNome.Text;
                    oLivro.Descricao = txtDescricao.Text;

                    // Verificar e atribuir o valor de TxtEdicao
                    if (!string.IsNullOrWhiteSpace(TxtEdicao.Text) && int.TryParse(TxtEdicao.Text, out int edicao))
                    {
                        oLivro.Edicao = edicao;
                    }

                    // Verificar e atribuir o valor de txtQntPag
                    if (!string.IsNullOrWhiteSpace(txtQntPag.Text) && int.TryParse(txtQntPag.Text, out int paginas))
                    {
                        oLivro.Paginas = paginas;
                    }

                    // Verificar e atribuir o valor de comboBoxGenero.SelectedValue
                    if (comboBoxGenero.SelectedValue != null && int.TryParse(comboBoxGenero.SelectedValue.ToString(), out int idGenero))
                    {
                        oLivro.IdGenero = idGenero;
                    }

                    // Verificar e atribuir o valor de comboBoxIdioma.SelectedValue
                    if (comboBoxIdioma.SelectedValue != null && int.TryParse(comboBoxIdioma.SelectedValue.ToString(), out int idIdioma))
                    {
                        oLivro.IdIdioma = idIdioma;
                    }

                    // Verificar e atribuir o valor de comboBoxEditora.SelectedValue
                    if (comboBoxEditora.SelectedValue != null && int.TryParse(comboBoxEditora.SelectedValue.ToString(), out int idEditora))
                    {
                        oLivro.IdEditora = idEditora;
                    }

                    dataGridViewLivro.AutoGenerateColumns = false;
                    dataGridViewLivro.DataSource = Livro.SelecionarPorChave(oLivro);
                    dataGridViewAutor.DataSource = Livro.CarregaAutores(oLivro);
                    Pesquisar = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao realizar a pesquisa: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {

                dataGridViewLivro.AutoGenerateColumns = false;
                dataGridViewAutor.AutoGenerateColumns = false;
                dataGridViewLivro.DataSource = Livro.ListarTodos();
                dataGridViewAutor.DataSource = Livro.ListarTodosAutores();
                comboBoxEditora.DataSource = SistemaBiblioteca.Model.Editora.ListarTodos();
                comboBoxEditora.ValueMember = "id";
                comboBoxEditora.DisplayMember = "Nome";

                comboBoxIdioma.DataSource = SistemaBiblioteca.Model.Idioma.ListarTodos();
                comboBoxIdioma.ValueMember = "id";
                comboBoxIdioma.DisplayMember = "Nome";

                comboBoxGenero.DataSource = SistemaBiblioteca.Model.Genero.ListarTodos();
                comboBoxGenero.ValueMember = "id";
                comboBoxGenero.DisplayMember = "Nome";
            }

        }

        private void LimpaControles()
        {
            TxtCodigo.Text = "";
            txtISBN.Text = "";
            TxtNome.Text = "";
            txtDescricao.Text = "";
            comboBoxEditora.Text = "";
            TxtEdicao.Text = "";
            txtQntPag.Text = "";
            comboBoxIdioma.Text = "";
            comboBoxGenero.Text = "";
            comboBoxGenero.SelectedIndex = -1;
            comboBoxIdioma.SelectedIndex = -1;
            comboBoxEditora.SelectedIndex = -1;
        }

        private void FrmLivro_FormClosed(object sender, FormClosedEventArgs e)
        {
            ((FrmMenu)this.MdiParent).menuStrip.Enabled = true;
            ((FrmMenu)this.MdiParent).MenuSuspenso.Enabled = true;
            ((FrmMenu)this.MdiParent).lblStatus.Text = "";
        }

        private void FrmLivro_Load(object sender, EventArgs e)
        {
            CarregaGrid();
            LimpaControles();
        }

        private void FrmLivro_Activated(object sender, EventArgs e)
        {
            ((FrmMenu)this.MdiParent).lblStatus.Text = "Cadastrando Livro...";
        }

        private bool ValidaControles()
        {
            if (Pesquisar)
            {
                
            }
            else
            {
                List<int> valoresid = new List<int>();
                foreach (DataGridViewRow linha in dataGridViewAutor.Rows)
                {
                    if (Convert.ToBoolean(linha.Cells["Selecionar"].Value))
                    {
                        valoresid.Add(Convert.ToInt32(linha.Cells["IdAutor"].Value));
                    }
                }
                int Codigo;
                if (TxtNome.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Nome é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (txtDescricao.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Descricao é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (txtISBN.Text.Trim() == "")
                {
                    MessageBox.Show("O campo ISBN é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (txtQntPag.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Quantidade de páginas é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (TxtEdicao.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Edição é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (comboBoxEditora.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Editora é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (comboBoxGenero.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Genero é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (comboBoxIdioma.Text.Trim() == "")
                {
                    MessageBox.Show("O campo Idioma é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtNome.Focus();
                    return false;
                }

                else if (int.TryParse(txtQntPag.Text, out Codigo) == false)
                {
                    MessageBox.Show("O campo Quantidade de páginas não é numérico!", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                    return false;
                }

                else if (int.TryParse(TxtEdicao.Text, out Codigo) == false)
                {
                    MessageBox.Show("O campo Edicao de páginas não é numérico!", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                    return false;
                }

                else if (valoresid == null || valoresid.Count == 0)
                {
                    MessageBox.Show("É necessário selecionar ao menos 1 autor!", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                    return false;
                }
            }
            return true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (Incluir)
            {
                if (ValidaControles())
                {


                    // Itera sobre as linhas selecionadas e adiciona o valor da coluna à lista
                    List<int> valoresid = new List<int>();
                    foreach (DataGridViewRow linha in dataGridViewAutor.Rows)
                    {
                        if (Convert.ToBoolean(linha.Cells["Selecionar"].Value))
                        {
                            valoresid.Add(Convert.ToInt32(linha.Cells["IdAutor"].Value));
                        }
                        // Substitua 0 pelo índice da coluna que você deseja

                        //valor = Convert.ToInt32(linha.Cells[0].Value);
                        //valoresColuna.Add(valor);
                    }

                    Livro oLivro = new Livro
                    {
                        ISBN = txtISBN.Text,
                        Nome = TxtNome.Text,
                        Descricao = txtDescricao.Text,
                        Edicao = int.Parse(TxtEdicao.Text),
                        Paginas = int.Parse(txtQntPag.Text),
                        IdGenero = int.Parse(comboBoxGenero.SelectedValue.ToString()),
                        IdIdioma = int.Parse(comboBoxIdioma.SelectedValue.ToString()),
                        IdEditora = int.Parse(comboBoxEditora.SelectedValue.ToString()),
                        IdAutores = valoresid
                    };
                    //try
                    //{
                    //    int teste = int.Parse(comboBoxIdioma.SelectedValue.ToString());
                    //    int teste2 = int.Parse(comboBoxEditora.SelectedValue.ToString());
                    //    oLivro.IdGenero = int.Parse(comboBoxGenero.SelectedValue.ToString());
                    //}
                    //catch (FormatException)
                    //{
                    //    MessageBox.Show("O valor selecionado não é um número válido.");
                    //}
                    //catch (Exception ex)
                    //{
                    //    MessageBox.Show($"Ocorreu um erro: {ex.Message}");
                    //}

                    //IdEditora = int.Parse(comboBoxEditora.SelectedValue.ToString()),
                    //IdGenero = int.Parse(comboBoxGenero.SelectedValue.ToString()),



                    try
                    {
                        oLivro.Incluir();


                        CarregaGrid();
                        LimpaControles();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TxtCodigo.Focus();
                    }
                }
            }
            else
            {
                if (ValidaControles())
                {
                    List<int> valoresid = new List<int>();
                    foreach (DataGridViewRow linha in dataGridViewAutor.Rows)
                    {
                        if (Convert.ToBoolean(linha.Cells["Selecionar"].Value))
                        {
                            valoresid.Add(Convert.ToInt32(linha.Cells["IdAutor"].Value));
                        }
                        // Substitua 0 pelo índice da coluna que você deseja

                        //valor = Convert.ToInt32(linha.Cells[0].Value);
                        //valoresColuna.Add(valor);
                    }

                    Livro oLivro = new Livro
                    {
                        Id = int.Parse(TxtCodigo.Text),
                        ISBN = txtISBN.Text,
                        Nome = TxtNome.Text,
                        Descricao = txtDescricao.Text,
                        Edicao = int.Parse(TxtEdicao.Text),
                        Paginas = int.Parse(txtQntPag.Text),
                        IdGenero = int.Parse(comboBoxGenero.SelectedValue.ToString()),
                        IdIdioma = int.Parse(comboBoxIdioma.SelectedValue.ToString()),
                        IdEditora = int.Parse(comboBoxEditora.SelectedValue.ToString()),
                        IdAutores = valoresid
                    };
                    Livro.Alterar(oLivro);
                }
                try
                {

                    CarregaGrid();
                    LimpaControles();
                    Incluir = true;
                    TxtCodigo.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                }

            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TxtCodigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewLivro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridViewLivro.Rows[e.RowIndex].DataBoundItem != null)
                {
                    Livro objselecionado = (Livro)dataGridViewLivro.Rows[e.RowIndex].DataBoundItem;
                    Livro oLivro = new Livro();

                    if (dataGridViewLivro.Columns[e.ColumnIndex].Name == "Id")
                    {
                        oLivro.Id = objselecionado.Id;
                        dataGridViewAutor.AutoGenerateColumns = false;
                        dataGridViewAutor.DataSource = Livro.CarregaAutores(oLivro);
                    }

                    if (dataGridViewLivro.Columns[e.ColumnIndex].Name == "BtnAlterar")
                    {
                        TxtCodigo.Text = objselecionado.Id.ToString();
                        TxtNome.Text = objselecionado.Nome;
                        txtISBN.Text = objselecionado.ISBN;
                        txtDescricao.Text = objselecionado.Descricao;
                        comboBoxEditora.Text = objselecionado.Editora;
                        TxtEdicao.Text = objselecionado.Edicao.ToString();
                        txtQntPag.Text = objselecionado.Paginas.ToString();
                        comboBoxIdioma.Text = objselecionado.Idioma;
                        comboBoxGenero.Text = objselecionado.Genero;
                        dataGridViewAutor.DataSource = Livro.CarregaAutores(objselecionado);
                        foreach (DataGridViewRow row in dataGridViewAutor.Rows)
                        {
                            row.Cells["Selecionar"].Value = true;
                        }

                        //for (int i = 0; i < Livro.CarregaAutores(objselecionado).LongCount(); i++)
                        //{
                        //    Autor autor = new Autor();
                        //    autor = Livro.CarregaAutores(objselecionado)[i];
                        //    if autor 
                        //}


                        TxtCodigo.Enabled = false;

                        //TxtNome.Focus();
                        Incluir = false;
                    }
                    else if (dataGridViewLivro.Columns[e.ColumnIndex].Name == "BtnExcluir")
                    {
                        if (MessageBox.Show("Confirme a exclusão", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            objselecionado.Excluir();
                            CarregaGrid();
                            LimpaControles();

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Utilize os botões da Grid", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtCodigo.Focus();
            }
        }

        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            Pesquisar = true;
            TxtCodigo.Enabled = true;
            if (ValidaControles())
            {
                CarregaGrid();
                LimpaControles();
            }
            else
            {
                Pesquisar = false;
                CarregaGrid();
                LimpaControles();
            }
        }

        private void dataGridViewAutor_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridViewAutor.Rows[e.RowIndex].DataBoundItem != null)
                {



                    if (dataGridViewAutor.Columns[e.ColumnIndex].Name == "Excluir")
                    {
                        if (MessageBox.Show("Confirme a exclusão", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            Autor objselecionado = (Autor)dataGridViewAutor.Rows[e.RowIndex].DataBoundItem;
                            Livro oLivro = new Livro();
                            oLivro.Id = int.Parse(TxtCodigo.Text);
                            Autor oAutor = new Autor();
                            oAutor.Id = objselecionado.Id;
                            dataGridViewAutor.AutoGenerateColumns = false;
                            Livro.ExcluirAutor(oAutor, oLivro);

                            CarregaGrid();

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Utilize os botões da Grid", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtCodigo.Focus();
            }
        }

        private void btnListarAutores_Click(object sender, EventArgs e)
        {
            dataGridViewAutor.DataSource = Livro.ListarTodosAutores();
            LimpaControles();
        }

        private void btnRegarregalivros_Click(object sender, EventArgs e)
        {
            dataGridViewLivro.DataSource = Livro.ListarTodos();
            LimpaControles();
        }
    }
}
