﻿using SistemaBiblioteca.Helper;
using SistemaBiblioteca.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SistemaBiblioteca
{
    public partial class FrmLivro : Form
    {

        private bool Incluir = true;
        private bool Pesquisar = false;
        public FrmLivro()
        {
            InitializeComponent();
        }

        private void CarregaGrid()
        {
            if (Pesquisar)
            {
                Livro oLivro = new Livro
                {
                    Id = int.Parse(TxtCodigo.Text)
                };
                dataGridViewLivro.AutoGenerateColumns = false;
                dataGridViewLivro.DataSource = Livro.SelecionarPorChave(oLivro);
                Pesquisar = false;
            }
            else
            {

                dataGridViewLivro.AutoGenerateColumns = false;
                dataGridViewAutor.AutoGenerateColumns = false;
                dataGridViewLivro.DataSource = Livro.ListarTodos();
                dataGridViewAutor.DataSource = Livro.ListarTodosAutores();
                comboBoxEditora.DataSource = SistemaBiblioteca.Model.Editora.ListarTodos();
                comboBoxEditora.ValueMember = "id";
                comboBoxEditora.DisplayMember = "Nome";

                comboBoxIdioma.DataSource = SistemaBiblioteca.Model.Idioma.ListarTodos();
                comboBoxIdioma.ValueMember = "id";
                comboBoxIdioma.DisplayMember = "Nome";

                comboBoxGenero.DataSource = SistemaBiblioteca.Model.Genero.ListarTodos();
                comboBoxGenero.ValueMember = "id";
                comboBoxGenero.DisplayMember = "Nome";
            }

        }

        private void LimpaControles()
        {
            txtISBN.Text = "";
            TxtNome.Text = "";
            txtDescricao.Text = "";
            comboBoxEditora.Text = "";
            TxtEdicao.Text = "";
            txtQntPag.Text = "";
            comboBoxIdioma.Text = "";
            comboBoxGenero.Text = "";
        }

        private void FrmLivro_FormClosed(object sender, FormClosedEventArgs e)
        {
            ((FrmMenu)this.MdiParent).menuStrip.Enabled = true;
            ((FrmMenu)this.MdiParent).MenuSuspenso.Enabled = true;
            ((FrmMenu)this.MdiParent).lblStatus.Text = "";
        }

        private void FrmLivro_Load(object sender, EventArgs e)
        {
            CarregaGrid();
            LimpaControles();
        }

        private void FrmLivro_Activated(object sender, EventArgs e)
        {
            ((FrmMenu)this.MdiParent).lblStatus.Text = "Cadastrando Livro...";
        }

        private bool ValidaControles()
        {
            if (Pesquisar)
            {
                int Codigo;
                if (TxtCodigo.Text.Trim() == "")
                {
                    MessageBox.Show("O campo código é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                    return false;
                }
                else if (int.TryParse(TxtCodigo.Text, out Codigo) == false)
                {
                    MessageBox.Show("O campo código não é numérico!", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                    return false;
                }

            }

            else if (TxtNome.Text.Trim() == "")
            {
                MessageBox.Show("O campo Nome é de preenchimento obrigatório", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtNome.Focus();
                return false;
            }

            return true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (Incluir)
            {
                if (ValidaControles())
                {


                    // Itera sobre as linhas selecionadas e adiciona o valor da coluna à lista
                    List<int> valoresid = new List<int>();
                    foreach (DataGridViewRow linha in dataGridViewAutor.Rows)
                    {
                        if (Convert.ToBoolean(linha.Cells["Selecionar"].Value))
                        {
                            valoresid.Add(Convert.ToInt32(linha.Cells["IdAutor"].Value));
                        }
                        // Substitua 0 pelo índice da coluna que você deseja

                        //valor = Convert.ToInt32(linha.Cells[0].Value);
                        //valoresColuna.Add(valor);
                    }

                    Livro oLivro = new Livro
                    {
                        ISBN = txtISBN.Text,
                        Nome = TxtNome.Text,
                        Descricao = txtDescricao.Text,
                        Editora = comboBoxEditora.Text,
                        Edicao = int.Parse(TxtEdicao.Text),
                        Paginas = int.Parse(txtQntPag.Text),
                        Idioma = comboBoxIdioma.Text,
                        Genero = comboBoxGenero.Text,
                        IdAutores = valoresid

                    };

                    try
                    {
                        oLivro.Incluir();


                        CarregaGrid();
                        LimpaControles();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TxtCodigo.Focus();
                    }
                }
            }
            else
            {
                if (ValidaControles())
                {
                    Livro oLivro = new Livro
                    {
                        Id = int.Parse(TxtCodigo.Text),
                        ISBN = txtISBN.Text,
                        Nome = TxtNome.Text,
                        Descricao = txtDescricao.Text,
                        Editora = comboBoxEditora.Text,
                        Edicao = int.Parse(TxtEdicao.Text),
                        Paginas = int.Parse(txtQntPag.Text),
                        Idioma = comboBoxIdioma.Text,
                        Genero = comboBoxGenero.Text,
                    };
                    Livro.Alterar(oLivro);
                }
                try
                {

                    CarregaGrid();
                    LimpaControles();
                    Incluir = true;
                    TxtCodigo.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtCodigo.Focus();
                }

            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TxtCodigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewLivro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridViewLivro.Rows[e.RowIndex].DataBoundItem != null)
                {
                    Livro objselecionado = (Livro)dataGridViewLivro.Rows[e.RowIndex].DataBoundItem;
                    Livro oLivro = new Livro();

                    if (dataGridViewLivro.Columns[e.ColumnIndex].Name == "Id")
                    {
                        oLivro.Id = objselecionado.Id;
                        dataGridViewAutor.AutoGenerateColumns = false;
                        dataGridViewAutor.DataSource = Livro.CarregaAutores(oLivro);
                    }

                    if (dataGridViewLivro.Columns[e.ColumnIndex].Name == "BtnAlterar")
                    {
                        TxtCodigo.Text = objselecionado.Id.ToString();
                        TxtNome.Text = objselecionado.Nome;
                        txtISBN.Text = objselecionado.ISBN;
                        txtDescricao.Text = objselecionado.Descricao;
                        comboBoxEditora.Text = objselecionado.Editora;
                        TxtEdicao.Text = objselecionado.Edicao.ToString();
                        txtQntPag.Text = objselecionado.Paginas.ToString();
                        comboBoxIdioma.Text = objselecionado.Idioma;
                        comboBoxGenero.Text = objselecionado.Genero;

                        TxtCodigo.Enabled = false;

                        //TxtNome.Focus();
                        Incluir = false;
                    }
                    else if (dataGridViewLivro.Columns[e.ColumnIndex].Name == "BtnExcluir")
                    {
                        if (MessageBox.Show("Confirme a exclusão", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            objselecionado.Excluir();
                            CarregaGrid();

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Utilize os botões da Grid", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtCodigo.Focus();
            }
        }

        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            Pesquisar = true;
            TxtCodigo.Enabled = true;
            if (ValidaControles())
            {
                CarregaGrid();
                LimpaControles();
            }
            else
            {
                Pesquisar = false;
                CarregaGrid();
                LimpaControles();
            }
        }

        private void dataGridViewAutor_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridViewAutor.Rows[e.RowIndex].DataBoundItem != null)
                {
                    Autor objselecionado = (Autor)dataGridViewAutor.Rows[e.RowIndex].DataBoundItem;
                    Livro oLivro = new Livro();
                    oLivro.Id = int.Parse(TxtCodigo.Text);
                    Autor oAutor = new Autor();
        

                    if (dataGridViewAutor.Columns[e.ColumnIndex].Name == "Excluir")
                    {
                        if (MessageBox.Show("Confirme a exclusão", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            oAutor.Id = objselecionado.Id;
                            dataGridViewAutor.AutoGenerateColumns = false;
                            Livro.ExcluirAutor(oAutor, oLivro);
                       
                            CarregaGrid();

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Utilize os botões da Grid", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtCodigo.Focus();
            }
        }
    }
}
