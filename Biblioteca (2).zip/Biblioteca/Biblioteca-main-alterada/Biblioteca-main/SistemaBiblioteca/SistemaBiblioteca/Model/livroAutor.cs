﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaBiblioteca.Model
{
    public class livroAutor
    {    
        private int _IdLivro;
        private int _IdAutor;
        public int IdAutor
        {
            get { return _IdAutor; }
            set { _IdAutor = value; }

        }
        public int IdLivro
        {
            get { return _IdLivro; }
            set { _IdLivro = value; }

        }
    }
}
