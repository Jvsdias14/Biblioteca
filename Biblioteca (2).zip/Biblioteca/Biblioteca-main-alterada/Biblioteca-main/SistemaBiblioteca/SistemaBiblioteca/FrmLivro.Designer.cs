﻿namespace SistemaBiblioteca
{
    partial class FrmLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnSalvar = new Button();
            LblCodigo = new Label();
            lblNome = new Label();
            TxtCodigo = new TextBox();
            TxtNome = new TextBox();
            dataGridViewLivro = new DataGridView();
            Id = new DataGridViewTextBoxColumn();
            ISBN = new DataGridViewTextBoxColumn();
            Nome = new DataGridViewTextBoxColumn();
            Descricao = new DataGridViewTextBoxColumn();
            Editora = new DataGridViewTextBoxColumn();
            Edicao = new DataGridViewTextBoxColumn();
            Paginas = new DataGridViewTextBoxColumn();
            Idioma = new DataGridViewTextBoxColumn();
            Genero = new DataGridViewTextBoxColumn();
            BtnAlterar = new DataGridViewButtonColumn();
            BtnExcluir = new DataGridViewButtonColumn();
            BtnFechar = new Button();
            BtnPesquisar = new Button();
            lblIdioma = new Label();
            lblEditora = new Label();
            lblEdicao = new Label();
            TxtEdicao = new TextBox();
            txtISBN = new TextBox();
            lblISBN = new Label();
            lblgenero = new Label();
            comboBoxIdioma = new ComboBox();
            comboBoxEditora = new ComboBox();
            comboBoxGenero = new ComboBox();
            txtDescricao = new TextBox();
            lbldescricao = new Label();
            txtQntPag = new TextBox();
            lblquantidadepags = new Label();
            lblAutor = new Label();
            dataGridViewAutor = new DataGridView();
            IdAutor = new DataGridViewTextBoxColumn();
            NomeAutor = new DataGridViewTextBoxColumn();
            Excluir = new DataGridViewButtonColumn();
            Selecionar = new DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridViewLivro).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAutor).BeginInit();
            SuspendLayout();
            // 
            // BtnSalvar
            // 
            BtnSalvar.Location = new Point(991, 44);
            BtnSalvar.Name = "BtnSalvar";
            BtnSalvar.Size = new Size(101, 49);
            BtnSalvar.TabIndex = 0;
            BtnSalvar.Text = "Salvar";
            BtnSalvar.UseVisualStyleBackColor = true;
            BtnSalvar.Click += BtnSalvar_Click;
            // 
            // LblCodigo
            // 
            LblCodigo.AutoSize = true;
            LblCodigo.Location = new Point(21, 3);
            LblCodigo.Name = "LblCodigo";
            LblCodigo.Size = new Size(22, 20);
            LblCodigo.TabIndex = 1;
            LblCodigo.Text = "Id";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(83, 4);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(50, 20);
            lblNome.TabIndex = 2;
            lblNome.Text = "Nome";
            // 
            // TxtCodigo
            // 
            TxtCodigo.Location = new Point(21, 28);
            TxtCodigo.Name = "TxtCodigo";
            TxtCodigo.Size = new Size(56, 27);
            TxtCodigo.TabIndex = 3;
            // 
            // TxtNome
            // 
            TxtNome.Location = new Point(83, 29);
            TxtNome.Name = "TxtNome";
            TxtNome.Size = new Size(258, 27);
            TxtNome.TabIndex = 4;
            // 
            // dataGridViewLivro
            // 
            dataGridViewLivro.AllowUserToAddRows = false;
            dataGridViewLivro.AllowUserToDeleteRows = false;
            dataGridViewLivro.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewLivro.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewLivro.Columns.AddRange(new DataGridViewColumn[] { Id, ISBN, Nome, Descricao, Editora, Edicao, Paginas, Idioma, Genero, BtnAlterar, BtnExcluir });
            dataGridViewLivro.Location = new Point(22, 146);
            dataGridViewLivro.Name = "dataGridViewLivro";
            dataGridViewLivro.RowHeadersWidth = 51;
            dataGridViewLivro.Size = new Size(1178, 314);
            dataGridViewLivro.TabIndex = 5;
            dataGridViewLivro.CellClick += dataGridViewLivro_CellClick;
            // 
            // Id
            // 
            Id.DataPropertyName = "Id";
            Id.HeaderText = "Id";
            Id.MinimumWidth = 6;
            Id.Name = "Id";
            Id.ReadOnly = true;
            Id.Width = 75;
            // 
            // ISBN
            // 
            ISBN.DataPropertyName = "ISBN";
            ISBN.HeaderText = "ISBN";
            ISBN.MinimumWidth = 6;
            ISBN.Name = "ISBN";
            ISBN.ReadOnly = true;
            ISBN.Width = 125;
            // 
            // Nome
            // 
            Nome.DataPropertyName = "Nome";
            Nome.HeaderText = "Nome";
            Nome.MinimumWidth = 6;
            Nome.Name = "Nome";
            Nome.ReadOnly = true;
            Nome.Width = 300;
            // 
            // Descricao
            // 
            Descricao.DataPropertyName = "Descricao";
            Descricao.HeaderText = "Descrição";
            Descricao.MinimumWidth = 6;
            Descricao.Name = "Descricao";
            Descricao.ReadOnly = true;
            Descricao.Width = 125;
            // 
            // Editora
            // 
            Editora.DataPropertyName = "Editora";
            Editora.HeaderText = "Editora";
            Editora.MinimumWidth = 6;
            Editora.Name = "Editora";
            Editora.ReadOnly = true;
            Editora.Width = 125;
            // 
            // Edicao
            // 
            Edicao.DataPropertyName = "Edicao";
            Edicao.HeaderText = "Edicao";
            Edicao.MinimumWidth = 6;
            Edicao.Name = "Edicao";
            Edicao.ReadOnly = true;
            Edicao.Width = 125;
            // 
            // Paginas
            // 
            Paginas.DataPropertyName = "Paginas";
            Paginas.HeaderText = "Paginas";
            Paginas.MinimumWidth = 6;
            Paginas.Name = "Paginas";
            Paginas.ReadOnly = true;
            Paginas.Width = 125;
            // 
            // Idioma
            // 
            Idioma.DataPropertyName = "Idioma";
            Idioma.HeaderText = "Idioma";
            Idioma.MinimumWidth = 6;
            Idioma.Name = "Idioma";
            Idioma.ReadOnly = true;
            Idioma.Width = 125;
            // 
            // Genero
            // 
            Genero.DataPropertyName = "Genero";
            Genero.HeaderText = "Gênero";
            Genero.MinimumWidth = 6;
            Genero.Name = "Genero";
            Genero.ReadOnly = true;
            Genero.Width = 125;
            // 
            // BtnAlterar
            // 
            BtnAlterar.DataPropertyName = "BtnAlterar";
            BtnAlterar.HeaderText = "Alterar";
            BtnAlterar.MinimumWidth = 6;
            BtnAlterar.Name = "BtnAlterar";
            BtnAlterar.Width = 125;
            // 
            // BtnExcluir
            // 
            BtnExcluir.DataPropertyName = "BtnExcluir";
            BtnExcluir.HeaderText = "Excluir";
            BtnExcluir.MinimumWidth = 6;
            BtnExcluir.Name = "BtnExcluir";
            BtnExcluir.Text = "X";
            BtnExcluir.Width = 125;
            // 
            // BtnFechar
            // 
            BtnFechar.Location = new Point(1099, 44);
            BtnFechar.Name = "BtnFechar";
            BtnFechar.Size = new Size(101, 49);
            BtnFechar.TabIndex = 6;
            BtnFechar.Text = "Fechar";
            BtnFechar.UseVisualStyleBackColor = true;
            BtnFechar.Click += BtnFechar_Click;
            // 
            // BtnPesquisar
            // 
            BtnPesquisar.Location = new Point(884, 44);
            BtnPesquisar.Name = "BtnPesquisar";
            BtnPesquisar.Size = new Size(101, 49);
            BtnPesquisar.TabIndex = 8;
            BtnPesquisar.Text = "Pesquisar";
            BtnPesquisar.UseVisualStyleBackColor = true;
            BtnPesquisar.Click += BtnPesquisar_Click;
            // 
            // lblIdioma
            // 
            lblIdioma.AutoSize = true;
            lblIdioma.Location = new Point(21, 58);
            lblIdioma.Name = "lblIdioma";
            lblIdioma.Size = new Size(56, 20);
            lblIdioma.TabIndex = 9;
            lblIdioma.Text = "Idioma";
            // 
            // lblEditora
            // 
            lblEditora.AutoSize = true;
            lblEditora.Location = new Point(153, 58);
            lblEditora.Name = "lblEditora";
            lblEditora.Size = new Size(57, 20);
            lblEditora.TabIndex = 11;
            lblEditora.Text = "Editora";
            // 
            // lblEdicao
            // 
            lblEdicao.AutoSize = true;
            lblEdicao.Location = new Point(460, 60);
            lblEdicao.Name = "lblEdicao";
            lblEdicao.Size = new Size(54, 20);
            lblEdicao.TabIndex = 13;
            lblEdicao.Text = "Edição";
            // 
            // TxtEdicao
            // 
            TxtEdicao.Location = new Point(460, 87);
            TxtEdicao.Name = "TxtEdicao";
            TxtEdicao.Size = new Size(132, 27);
            TxtEdicao.TabIndex = 14;
            // 
            // txtISBN
            // 
            txtISBN.Location = new Point(605, 87);
            txtISBN.Name = "txtISBN";
            txtISBN.Size = new Size(150, 27);
            txtISBN.TabIndex = 16;
            // 
            // lblISBN
            // 
            lblISBN.AutoSize = true;
            lblISBN.Location = new Point(605, 60);
            lblISBN.Name = "lblISBN";
            lblISBN.Size = new Size(41, 20);
            lblISBN.TabIndex = 15;
            lblISBN.Text = "ISBN";
            // 
            // lblgenero
            // 
            lblgenero.AutoSize = true;
            lblgenero.Location = new Point(285, 58);
            lblgenero.Name = "lblgenero";
            lblgenero.Size = new Size(57, 20);
            lblgenero.TabIndex = 17;
            lblgenero.Text = "Gênero";
            // 
            // comboBoxIdioma
            // 
            comboBoxIdioma.FormattingEnabled = true;
            comboBoxIdioma.Location = new Point(21, 86);
            comboBoxIdioma.Name = "comboBoxIdioma";
            comboBoxIdioma.Size = new Size(126, 28);
            comboBoxIdioma.TabIndex = 18;
            // 
            // comboBoxEditora
            // 
            comboBoxEditora.FormattingEnabled = true;
            comboBoxEditora.Location = new Point(153, 86);
            comboBoxEditora.Name = "comboBoxEditora";
            comboBoxEditora.Size = new Size(126, 28);
            comboBoxEditora.TabIndex = 19;
            // 
            // comboBoxGenero
            // 
            comboBoxGenero.FormattingEnabled = true;
            comboBoxGenero.Location = new Point(285, 86);
            comboBoxGenero.Name = "comboBoxGenero";
            comboBoxGenero.Size = new Size(126, 28);
            comboBoxGenero.TabIndex = 20;
            // 
            // txtDescricao
            // 
            txtDescricao.Location = new Point(347, 29);
            txtDescricao.Name = "txtDescricao";
            txtDescricao.Size = new Size(320, 27);
            txtDescricao.TabIndex = 22;
            // 
            // lbldescricao
            // 
            lbldescricao.AutoSize = true;
            lbldescricao.Location = new Point(347, 4);
            lbldescricao.Name = "lbldescricao";
            lbldescricao.Size = new Size(74, 20);
            lbldescricao.TabIndex = 21;
            lbldescricao.Text = "Descrição";
            // 
            // txtQntPag
            // 
            txtQntPag.Location = new Point(673, 29);
            txtQntPag.Name = "txtQntPag";
            txtQntPag.Size = new Size(82, 27);
            txtQntPag.TabIndex = 24;
            // 
            // lblquantidadepags
            // 
            lblquantidadepags.AutoSize = true;
            lblquantidadepags.Location = new Point(673, 4);
            lblquantidadepags.Name = "lblquantidadepags";
            lblquantidadepags.Size = new Size(67, 20);
            lblquantidadepags.TabIndex = 23;
            lblquantidadepags.Text = "Qnt. Pag.";
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.Location = new Point(22, 492);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(118, 20);
            lblAutor.TabIndex = 25;
            lblAutor.Text = "Autores do Livro";
            // 
            // dataGridViewAutor
            // 
            dataGridViewAutor.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAutor.Columns.AddRange(new DataGridViewColumn[] { IdAutor, NomeAutor, Excluir, Selecionar });
            dataGridViewAutor.Location = new Point(22, 525);
            dataGridViewAutor.Name = "dataGridViewAutor";
            dataGridViewAutor.RowHeadersWidth = 51;
            dataGridViewAutor.Size = new Size(547, 314);
            dataGridViewAutor.TabIndex = 27;
            dataGridViewAutor.CellClick += dataGridViewAutor_CellClick;
            // 
            // IdAutor
            // 
            IdAutor.DataPropertyName = "Id";
            IdAutor.HeaderText = "Id Autor";
            IdAutor.MinimumWidth = 6;
            IdAutor.Name = "IdAutor";
            IdAutor.ReadOnly = true;
            IdAutor.Width = 125;
            // 
            // NomeAutor
            // 
            NomeAutor.DataPropertyName = "Nome";
            NomeAutor.HeaderText = "Nome Autor";
            NomeAutor.MinimumWidth = 6;
            NomeAutor.Name = "NomeAutor";
            NomeAutor.ReadOnly = true;
            NomeAutor.Width = 150;
            // 
            // Excluir
            // 
            Excluir.DataPropertyName = "BtnExcluir";
            Excluir.HeaderText = "Excluir";
            Excluir.MinimumWidth = 6;
            Excluir.Name = "Excluir";
            Excluir.Width = 125;
            // 
            // Selecionar
            // 
            Selecionar.HeaderText = "Selecionar";
            Selecionar.MinimumWidth = 6;
            Selecionar.Name = "Selecionar";
            Selecionar.Width = 90;
            // 
            // FrmLivro
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1212, 921);
            Controls.Add(dataGridViewAutor);
            Controls.Add(lblAutor);
            Controls.Add(txtQntPag);
            Controls.Add(lblquantidadepags);
            Controls.Add(txtDescricao);
            Controls.Add(lbldescricao);
            Controls.Add(comboBoxGenero);
            Controls.Add(comboBoxEditora);
            Controls.Add(comboBoxIdioma);
            Controls.Add(lblgenero);
            Controls.Add(txtISBN);
            Controls.Add(lblISBN);
            Controls.Add(TxtEdicao);
            Controls.Add(lblEdicao);
            Controls.Add(lblEditora);
            Controls.Add(lblIdioma);
            Controls.Add(BtnPesquisar);
            Controls.Add(BtnFechar);
            Controls.Add(dataGridViewLivro);
            Controls.Add(TxtNome);
            Controls.Add(TxtCodigo);
            Controls.Add(lblNome);
            Controls.Add(LblCodigo);
            Controls.Add(BtnSalvar);
            MinimizeBox = false;
            Name = "FrmLivro";
            Text = "Cadastrar Livro";
            WindowState = FormWindowState.Maximized;
            Activated += FrmLivro_Activated;
            FormClosed += FrmLivro_FormClosed;
            Load += FrmLivro_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewLivro).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAutor).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnSalvar;
        private Label LblCodigo;
        private Label lblNome;
        private TextBox TxtCodigo;
        private TextBox TxtNome;
        private DataGridView dataGridViewLivro;
        private Button BtnFechar;
        private Button BtnPesquisar;
        private Label lblIdioma;
        private Label lblEditora;
        private Label lblEdicao;
        private TextBox TxtEdicao;
        private TextBox txtISBN;
        private Label lblISBN;
        private Label lblgenero;
        private ComboBox comboBoxIdioma;
        private ComboBox comboBoxEditora;
        private ComboBox comboBoxGenero;
        private TextBox txtDescricao;
        private Label lbldescricao;
        private TextBox txtQntPag;
        private Label lblquantidadepags;
        private Label lblAutor;
        private DataGridView dataGridViewAutor;
        private DataGridViewTextBoxColumn Id;
        private DataGridViewTextBoxColumn ISBN;
        private DataGridViewTextBoxColumn Nome;
        private DataGridViewTextBoxColumn Descricao;
        private DataGridViewTextBoxColumn Editora;
        private DataGridViewTextBoxColumn Edicao;
        private DataGridViewTextBoxColumn Paginas;
        private DataGridViewTextBoxColumn Idioma;
        private DataGridViewTextBoxColumn Genero;
        private DataGridViewButtonColumn BtnAlterar;
        private DataGridViewButtonColumn BtnExcluir;
        private DataGridViewTextBoxColumn IdAutor;
        private DataGridViewTextBoxColumn NomeAutor;
        private DataGridViewButtonColumn Excluir;
        private DataGridViewCheckBoxColumn Selecionar;
    }
}
