﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SistemaBiblioteca
{
    public partial class FrmMenu : Form
    {
        public FrmMenu(string tipo)
        {
            InitializeComponent();
            _tipo = tipo;
        }
        private string _tipo;


        private void FrmMenu_Load(object sender, EventArgs e)
        {
            if (this._tipo == "ADM")
            {

            }
            else
            {
                usuariotoolStripMenuItem.Enabled = false;
            }
        }



        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void sairMenuSuspenso_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void TelaGenero(object sender, EventArgs e)
        {
            FrmGenero oFrmGenero = new FrmGenero();
            oFrmGenero.MdiParent = this;
            menuStrip.Enabled = false;
            MenuSuspenso.Enabled = false;
            oFrmGenero.Show();
        }

        private void TelaAutor(object sender, EventArgs e)
        {
            FrmAutor oFrmAutor = new FrmAutor();
            oFrmAutor.MdiParent = this;
            menuStrip.Enabled = false;
            MenuSuspenso.Enabled = false;
            oFrmAutor.Show();
        }
        private void TelaEditora(object sender, EventArgs e)
        {
            FrmEditora oFrmEditora = new FrmEditora();
            oFrmEditora.MdiParent = this;
            menuStrip.Enabled = false;
            MenuSuspenso.Enabled = false;
            oFrmEditora.Show();
        }

        private void TelaIdioma(object sender, EventArgs e)
        {
            FrmIdioma oFrmIdioma = new FrmIdioma();
            oFrmIdioma.MdiParent = this;
            menuStrip.Enabled = false;
            MenuSuspenso.Enabled = false;
            oFrmIdioma.Show();
        }
        private void TelaUsuario(object sender, EventArgs e)
        {
            FrmUsuario oFrmUsuario = new FrmUsuario();
            oFrmUsuario.MdiParent = this;
            menuStrip.Enabled = false;
            MenuSuspenso.Enabled = false;
            oFrmUsuario.Show();
        }

        private void TelaLivro(object sender, EventArgs e)
        {
            FrmLivro oFrmLivro = new FrmLivro();
            oFrmLivro.MdiParent = this;
            menuStrip.Enabled = false;
            MenuSuspenso.Enabled = false;
            oFrmLivro.Show();
        }

        private void FrmMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }

}
